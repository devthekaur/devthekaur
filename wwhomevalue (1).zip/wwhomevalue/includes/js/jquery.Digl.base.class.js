var Digl;
(function ( $ ) { 
    $(document).ready(function(){
        $('.submit_form').click(function(e){
            e.preventDefault();
            var first_name = $('#first_name').val();
            var last_name = $('#last_name').val();
            var email = $('#email').val();
            var phone = $('#phone').val();
            if(email ==''){
                alert('Please enter email');
            }else{
                if (!validEmail(email)) {
                    alert('Please enter valid email'); 
                }else{
                    jQuery.ajax({
                    type: "post",
                    url: 'http://localhost/wordpress/wp-admin/admin-ajax.php',
                    data : {action: "_digl_sendmessage",'first_name':first_name,'last_name':last_name,'email':email,'email':email,'phone':phone},
                        success: function(response){
                            console.log(response);
                            // var dataResult = JSON.parse(response);
                           
                            
                        }
                    });
                } 
            }
        });

        Digl = {
            private: {
                debugger:true, 
                base_url:'',
                ajax_path:'',
                homeowner_name:'',
                validated:false
            },
            init: function(obj) {
                if (typeof obj.debugger !== 'undefined') {
                    this.private.debugger = obj.debugger;
                }
                if (typeof obj.base_url !== 'undefined') {
                    this.private.base_url = obj.base_url;
                }
                if (typeof obj.ajax_path !== 'undefined') {
                    this.private.ajax_path = obj.ajax_path;
                }
                $('#upload_logo_form').attr("action",this.private.ajax_path);
                
            },
            formResults:{
                
            },
            formChanges:{
                navigate:function(page,i) {
                    $('#page_'+page).fadeOut("fast",function(){
                        $('#page_'+(page + i)).fadeIn("fast",function(){
                            $('html, body').animate({ scrollTop: $('h1').offset().top }, 'slow');
                        }) ;
                    });
                }
            },
            formValidation:{
                validate:function(t,b,er,re){
                    var $return = true;
                    if (typeof er === "undefined") {
                        er = "* Required";
                    }
                    if (typeof re === "undefined") {
                        re = "";
                    }
                    // true == loop through all required on page
                    if (true === b) {
                        $("#"+t.attr("id")).find('.required').each(function() {
                            if ($(this).val() == "") {
                                $(this).parent().find(".err_message").html(er);
                                $return = false;
                            } else {
                                $(this).parent().find(".err_message").html(re);
                            }
                        });
                    } else {
                        if (t.val() == "") {
                            t.parent().find(".err_message").html(er);
                            $return = false;
                        } else {
                            t.parent().find(".err_message").html(re);
                        }
                    }
                    return $return;
                },
                bind_keyPress:function(action,callback) {
                    // Click Events
                    $('form').on("click",'.submit_form',function(){
                        if (false == Digl.private.validated) {
                            alert("Please enter email address.");
                            return false;
                        }
                        var i = 0;
                         var data = {imp_chk:[]};
                        var $form = $(this).closest('form');
                        $form.find('input,select,textarea').each(function(){
                            if (!$(this).hasClass("digm")) {
                                if ($(this).val() == 'on') {
                                    data.imp_chk[i] = $(this).is(":checked");
                                    i++;
                                } else {
                                    var id = $(this).attr("id");
                                    if (id === undefined) {
                                        id = i++;
                                    }
                                    var required = 0;
                                    if ($(this).hasClass("required")) {
                                        required = 1;
                                    }
                                    var field = {message:$(this).val(),required:required}
                                    data[id] = field;
                                }
                            }
                        });
                        var promise = Digl.core.getData(action,data);
                        callback(promise);
                    });
                    $('form').on("click",'#reset',function(){
                        $('form').find('input,select,textarea').each(function(){
                            $(this).val("");
                        });
                    });
                    // Click Events for Plugin Options
                    // Blur Events
                    $('form').on("blur",".required",function(){
                        if ($(this).closest("section").hasClass("validate")) {
                            Digl.private.validated = Digl.formValidation.validate($(this),false);   
                        }
                        /*if ($(this).closest("section").hasClass("vemail")) {
                            Digl.private.validated = Digl.formValidation.validate_email($(this));   
                        }*/
                    });
                    $('form').on("blur",".vemail",function(){
                        if ($(this).closest("section").hasClass("validate")) {
                            Digl.private.validated = Digl.formValidation.validate_email($(this));   
                        }
                    });
                    $('.phone').keypress(function(key) {
                        if(key.charCode < 48 || key.charCode > 57) return false;
                        if ($(this).val().length > 9) return false;
                    });
                },
                validate_email: function(t,d) {
                    
                    var $return = true;
                    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;   
                    if (re.test(t.val())) {
                       // alert(d);
                        if (typeof d === 'undefined') {
                            d = "";
                        }
                        t.parent().find(".err_message").html(d);
                    } else {
                        t.parent().find(".err_message").html("* Invalid Email");
                        $return = false;
                    }
                    return $return;
                }
            },
            core:{
                getData: function(method,data){
					

                    
                    $this = Digl;
                    var url = $this.private.ajax_path;
                    $this.core.logThis('send ajax');
                    var post = {
                        action :'digl_wp_ajax',
                        method :'post',
                        data:getData
                    };
                    return $.ajax({
                        url         :url,
                        data        :post,
                        type        :"post",
                        dataType:   "json"
                    });
                },
            
                dataResult: function(p,callback) {
					console.log(p);
                    console.log(getData);
                    console.log(post);

                    p.success( function(data){
                        if(data.success == 1) {
                        
                    
                            if (typeof callback === "function") {
                                callback(data);
                       
                             
                            }
                        } else {
                            if (typeof data.error !== 'undefined') {
                                var errors = "";
                                $.each(data.error,function(k,v){
                                    errors+=v+"\n";
                                });
                                alert("An error occured "+errors);
                            }
                        } 
                       
                    });
                    p.error( function(xhr, ajaxOptions, thrownError){
                        var error_text = 'An Error occurred...';
                        if ( typeof xhr !== 'undefined') {
                            Digl.core.logThis('xhr error '+xhr.status);
                        }
                        if ( typeof thrownError !== 'undefined') {
                            Digl.core.logThis('thrownError '+thrownError);
                        }
                       // alert(error_text); 
                    });
                },
                /**
                    * Sets up and run jQuery UI Datatable
                    * @method initDataTable
                    * @param {Object} $target : "table" to act on
                    * */
                    initDataTable: function($target) {
                        if ("dataTable" in $target) {
                            $target.dataTable({
                                "order": [[ 1, "desc" ]]
                            });
                        }
                },
                logThis:function(text){
                    if (Digl.private.debugger == true) {
                        if(window['console'] !== undefined){
                            console.log(text);
                        }
                    }
                },
                appendLoader:function($target){
                    $target.html('<center><img src="/wp-content/plugins/dig-widget/images/loading.gif" style="width:20%;" /></center>');
                }
            }
        }
        Digl.init({ajax_path:ajax_object.ajaxurl});
        //Digl.core.initDataTable($('#dig_app_forms'));
    });
}( jQuery ));

function validEmail(v) {
    var r = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
    return (v.match(r) == null) ? false : true;
}