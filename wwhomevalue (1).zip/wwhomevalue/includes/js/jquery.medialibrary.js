jQuery(document).ready(function($){
	var custom_uploader;
	var image_url_holder; // this should be what is actually passed to the server for saving
    var thumb_img; // this is what will be displayed to the user in the editor
	$('body').on("click",'.wp_ml_select_photo',function(e) {
		e.preventDefault();
		image_target = $(this).data("target");
		thumb_img = $(this).data("thumb-target");
		if (custom_uploader) {
			custom_uploader.open();
			return;
		}
		custom_uploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose Image',
			button: {
				text: 'Choose Image'
			},
			multiple: false
		});
		custom_uploader.on('select', function() {
                    
			attachment = custom_uploader.state().get('selection').first().toJSON();
			// 09/2014 - Fixed bug when customer had existing images with no thumbnails
			// 			 Caused an errror that breaks as 'undefined'
			//			 This fix loops through all WP known images and finds the first image
			//			 If that image is a thumbnail, it uses it, else it just uses as small an image as possible
			var thumb = false;
			$.each(attachment.sizes,function(k,v){
				if (false == thumb) {
					thumb = v.url;
				}
			});
			//thumb =  attachment.sizes.thumbnail.url;
				$(thumb_img).attr("src",thumb);
				$(image_target).val(attachment.url);
		});
		custom_uploader.open();
	});
});