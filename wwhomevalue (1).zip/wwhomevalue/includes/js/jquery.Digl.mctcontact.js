(function ( $ , window , document , undefined) {
$(document).ready(function(){
    alert('dev');

    die();


   
    Digl.formValidation.bind_keyPress('dig_sendmessage',function(p){

        Digl.core.dataResult(p,function(data){
            
           var redirectUrl = $(".redirect-url").text();
            $('input, textarea').each(function(){
                $(this).val('');

            });
            
            alert("Request sent successfully");  
          document.location.href=redirectUrl;
          alert('dev');
        });
    });
    $('textarea').keypress(function(){
        var max = $(this).data("max");
        var used = $(this).val().length;
        var left = max - used;
        if (left <= 0) {
            $(this).val($(this).val().substring(0,max));
        }
        $(this).parent().find(".number_of_chr").html("characters left:"+left);
    });
    $('#quicksell').on("click",function(){
      
       if (true === Digl.formValidation.validate_email($('#quicksell_txt'),'')) {
            var p = Digl.core.getData('dig_send_inforequest',{e:$('#quicksell_txt').val()});
            Digl.core.dataResult(p,function(){alert("Thank you for your interest.\nA representative will contact you soon.")});
       }
    });
});
} ( jQuery , window, document));