jQuery(document).ready(function($){
    $('.mct-color-field').wpColorPicker();
});