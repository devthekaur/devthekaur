<?php




function _digl_sendmessage(){



    global $digl_classContainer;
    global $errors;



    global $wpdb;


    $data = $digl_classContainer['general']->get_request('data',false);


    $table_name = $wpdb->prefix.'realty_reg';



    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {

//print_r($table_name);

        $exists = false;



        $columns = $wpdb->get_results('SHOW COLUMNS FROM `wp_realty_reg`');



        foreach($columns as $column){



            if($column->Field == 'reg_agent_from'){



                $exists = true;



                break;



            }



        }



        if(!$exists){



            $wpdb->query("ALTER TABLE `$table_name` ADD `reg_agent_from` VARCHAR(100) NOT NULL AFTER `reg_workwithagent`;");



        }

        $date_added = date('Y-m-d');



        $address = explode(',',$data['address']['message']);



        if(isset($address[1])){



            $city = $address[1];



        }else{



            $city = '';



        }



        if(isset($address[2])){



            $state = $address[2];



        }else{



            $state = '';



        }



        if(isset($address[3])){



            $zip = $address[3];



        }else{



            $zip = '';



        }



        $email = $data['email']['message'];



        $sql_reality_tag = "INSERT INTO `$table_name`



            (`firstname`,`lastname`,`emailaddress`,`phone`,`address1`,`city`,`state`,`zip`,`leadtype`,`dateadded`)



            VALUES



            ('".esc_sql($data['first_name']['message'])."',



            '".$data['last_name']['message']."',



            '".$data['email']['message']."',



            '".$data['phone']['message']."',



            '".$address[0]."',



            '".$city."',



            '".$state."',



            '".$zip."',



            'Seller',



            '".$date_added."')";



        // Start Realty Reg //



            $sql = "SELECT `emailaddress` FROM `$table_name`



                            WHERE `emailaddress` = '".esc_sql($email)."'



                            LIMIT 1";



            $reg = $wpdb->get_row($sql);



            if (empty($reg->emailaddress)) {        



                $sql = $wpdb->query($sql_reality_tag);;



            }else{



                $sql =  $wpdb->query("UPDATE `$table_name` SET



                                    `firstname` = '".esc_sql($data['first_name']['message'])."',



                                    `lastname` = '".$data['last_name']['message']."',



                                    `phone` = '".$data['phone']['message']."',



                                    `address1` = '".$address[0]."',



                                    `city` = '".$city."',



                                    `state` = '".$state."',



                                    `zip` = '".$zip."',



                                    `leadtype` = 'Seller',



                                    `dateadded` = '".$date_added."'



                                    WHERE `emailaddress` = '".$email."'");



            }



        // End Realty Reg //







        // Start Realty User //



           /* $user_table_name = $wpdb->prefix.'realty_users';



            if (mysql_num_rows(mysql_query("SHOW TABLES LIKE '$user_table_name'")) == 1){



                $sql = "SELECT `user_email` FROM `$user_table_name`



                            WHERE `user_email` = '".$data['email']['message']."'



                            LIMIT 1";



                $reg = $wpdb->get_row($sql);



                if (empty($reg->user_email)) {



                    $sql= $wpdb->query("INSERT INTO `$user_table_name` (`user_username`,`user_password`, `user_firstname` , `user_lastname` , `user_email` , `user_phone` ,`user_address1`,`user_city`,`user_state`,`user_location`,`user_leadtype`,`user_dateadded` )



                            VALUES (



                            '".$data['email']['message']."','".wp_hash_password($data['password']['message'])."','".esc_sql($data['first_name']['message'])."',



                            '".$data['last_name']['message']."',



                            '".$data['email']['message']."',



                            '".$data['phone']['message']."',



                            '".$address[0]."',



                            '".$city."',



                            '".$state."',



                            '".$zip."',



                            'Seller',



                            '".$date_added."')");



                }else{



                    $sql =  $wpdb->query("UPDATE `$user_table_name` SET



                                    `user_firstname` = '".esc_sql($data['first_name']['message'])."',



                                    `user_lastname` = '".$data['last_name']['message']."',



                                    `user_phone` = '".$data['phone']['message']."',



                                    `user_address1` = '".$address[0]."',



                                    `user_city` = '".$city."',



                                    `user_state` = '".$state."',



                                    `user_location` = '".$zip."',



                                    `user_leadtype` = 'Seller',



                                    `user_dateadded` = '".$date_added."'



                                    WHERE `user_email` = '".$data['email']['message']."'");



                }



            }*/



        // End Realty User //







        // Start UPICRM // 



            $crm_table_name = $wpdb->prefix.'upicrm_leads';



            if($wpdb->get_var("SHOW TABLES LIKE '$crm_table_name'") == $crm_table_name) {



                 $lead_content = array();



                 $lead_content['first-name'] = esc_sql($data['first_name']['message']);



                 $lead_content['last-name'] = $data['last_name']['message'];



                 $lead_content['email'] = $data['email']['message'];



                 $lead_content['phone'] = $data['phone']['message'];



                 $lead_content['address1'] = $address[0];



                 $lead_content['city'] = $city;



                 $lead_content['state'] = $state;



                 $lead_content['location'] =$zip;



                 $lead_content['creating-date'] = date('Y-m-d');



                 $lead_content['lead-type'] = 'Seller';



                 $lead_content = json_encode($lead_content);



                 $user_ip = $_SERVER['REMOTE_ADDR'];



                 $user_agent = $_SERVER['HTTP_USER_AGENT'];



                 $user = get_users( array( 'role' => 'Administrator' ));



                 $user_id = get_option('upicrm_default_lead');



                 $user_referer = home_url(add_query_arg(array(),$wp->request));



                 $time = date();



                    $sql = $wpdb->query("INSERT INTO `$crm_table_name` ( `source_type` , `source_id` , `lead_content` , `user_ip` , `user_agent` , `user_referer`, `old_user_lead_id`, `user_id`, `lead_status_id` )



                            VALUES (



                            '7', '30', '$lead_content', '$user_ip', '$user_agent', '$user_referer', '0','$user_id','1') ");



            }



        // End UPICRM // 



    }



    if (false === $data) {



        $errors[] = "no data to work on _dig_sendmessage ";



        return false;



    }



    if (!is_array($data)) {



        $errors[] = "array expected _dig_sendmessage";



        return false;



    }



    $subject = get_option('diglc_subject',false);



    if (false === $subject) {



        $errors[] = "subject is a required field _dig_sendmessage";



        return false;



    }



    if ('' == $subject) {



        $errors[] = "subject is a required field _dig_sendmessage";



        return false;



    }



    if (false === _dig_checkmessage($data)) {



        return false;



    }



    $required = get_option('diglc_form_field_required');



    



    $message = "";



    $from_email = '';



    $i = 0;



    foreach($data as $key => $value) {



        if (strpos($key,'mail') !== false) {



            if (strpos($value['message'],'@') !== false) {



                if ('' == $from_email)$from_email = $value['message'];



            }



        }



        $r = isset($required[$i]) ? $required[$i] : '';



        if ($r == 'required') {



            if (strlen($value['message']) < 1) {



                $errors[] = $key." is a required field";



                return false;



            }



        }



        $message.=ucwords(str_replace('_',' ',$key)).': '.$value['message']."\n";



        $i++;



    }



    $emails = get_option('diglc_destination_emails');



    if (!is_array($emails))$emails = array($emails);



    $params = array(



        'email'=>$emails,



        'subject'=>$subject,



        'message'=>$message,



        'from_email'=>$from_email



    );



//    print_r($params);



    $result = $digl_classContainer['general']->sendEmail($params);



    if (false === $result) {



        $errors[] = $digl_classContainer['general']->get_error_message();



        return false;



    }



    return true;



}







function _digl_send_inforequest()



{



    global $digl_classContainer;



    global $errors;



    $data = $digl_classContainer['general']->get_request('data',false);



    if (false === $data) {



        $errors[] = "no data to work on _dig_send_inforequest ";



        return false;



    }



    if (!is_array($data)) {



        $errors[] = "array expected _dig_send_inforequest";



        return false;



    }



    $subject = 'Request for free comparitive market analysis.';



    if (false === $subject) {



        $errors[] = "subject is a required field _dig_send_inforequest";



        return false;



    }



    $message = "A website visitor has expressed an interest in a free comparitive market analysis of their home.



    Customer Email: ".$data['e'];



    $from_email = '';



    $emails = get_option('diglc_destination_emails');



    if (!is_array($emails))$emails = array($emails);



    $params = array(



        'email'=>$emails,



        'subject'=>$subject,



        'message'=>$message,



        'reply_to'=>$data['e']



    );



    $result = $digl_classContainer['general']->sendEmail($params);



    if (false === $result) {



        $errors[] = $digl_classContainer['general']->get_error_message();



        return false;



    }



    return true;



}



function _dig_checkmessage($data)



{



    global $errors;



    global $digl_classContainer;



    global $digl_session;



    



    if (isset($digl_session['contact']['sample_ip'])) {



        if ($_SERVER['REMOTE_ADDR'] == $digl_session['contact']['sample_ip']) {



            if ( (int)$digl_session['contact']['requests'] > get_option('diglc_max_requests',5) ) {



                $errors[] = 'maximum requesrs for a given period reached...try again in 10 minutes';



                return false;



            }



            $sample = "-".(get_option('diglc_max_timeout',3000) / 1000)." second";



            if ($digl_session['contact']['sample_time'] > date('Y-m-d H:i:s',strtotime($sample)) ) {



                $errors[] = 'maximum requesrs for a given period reached...try again in '.(get_option('diglc_max_timeout',3000) / 1000).' seconds';



                return false;



            }



        }



    }



    if (isset($digl_session['contact']['requests'])) {



        $rfq = (int)$digl_session['contact']['requests'];



        $rfq++;



    }else{



        $rfq = 1;



    }



    $params = array(



        'init' => 1,



        'contact' => array(



            'sample_ip' => $_SERVER['REMOTE_ADDR'],



            'requests' => $rfq,



            'sample_time' => date('Y-m-d H:i:s')



        )



    );



    $digl_session = $digl_classContainer['session']->mdl_setSession($params);



    return true;



}



?>