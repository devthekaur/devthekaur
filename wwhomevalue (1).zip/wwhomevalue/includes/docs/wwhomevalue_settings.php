<style>
    #plugin_wrapper .fltleft {float: left}
    #plugin_wrapper .fltright {float: right}
    #plugin_wrapper .clear {clear: both}
    #plugin_wrapper h3 {
        display: block;
        background: #E8E5E5;
        border-radius: 3px;
        border: solid thin #C1BDBD;
        padding: 5px 8px 5px 8px;
        box-shadow: 1px 2px 2px #000;
        cursor: pointer;
    }
    .acc {
        background: #efefef; /* Old browsers */
        /* IE9 SVG, needs conditional override of 'filter' to 'none' */
        background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2VmZWZlZiIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNiYWJhYmEiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
        background: -moz-linear-gradient(top,  #efefef 0%, #bababa 100%); /* FF3.6+ */
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#efefef), color-stop(100%,#bababa)); /* Chrome,Safari4+ */
        background: -webkit-linear-gradient(top,  #efefef 0%,#bababa 100%); /* Chrome10+,Safari5.1+ */
        background: -o-linear-gradient(top,  #efefef 0%,#bababa 100%); /* Opera 11.10+ */
        background: -ms-linear-gradient(top,  #efefef 0%,#bababa 100%); /* IE10+ */
        background: linear-gradient(to bottom,  #efefef 0%,#bababa 100%); /* W3C */
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#efefef', endColorstr='#bababa',GradientType=0 ); /* IE6-8 */
        font-size: 20px;
        padding: 5px;
        margin-bottom: 3px;
        margin-left: -5px;
        cursor: pointer;
        border: solid 1px #000;
        width: 98%
    }
    #design_table .left {width: 150px; float: left}
    #design_table .right {width: 600px; float:left; max-height:150px; overflow-y: hidden}
    #design_table img {width: 300px}
    #text_table {width: 50%}
    #text_table .left {width: 150px}
    #text_table .right {}
    #text_table .right input {width: 100%}
    
    #social_table .left {width:150px}
    #social_table img {width: 200px; height: 200px}
    #social_table .right {width: 600px}
    #social_table .right input {width: 100%}
    
    #mapapikey_table {width: 700px}
    
    #mapapikey_table .left {width: 150px}
    
    #mapakikey_table .right {width: 600px}
    
    #mapapikey_table .right input {width: 100%}
    .wp-picker-holder{
		position: absolute;
	}
</style>
<?php
    $bad_words = array(
        'viagra',
        'cialis',
        'insurance',
        'VigRX',
        'megabonus',
        'online',
        'free',
        'jokes',
        'bad credit report',
        'debt relief',
        'payday loan',
        'cheap',
        'cheapest',
        'discount',
        'levitra',
        'cigarette',
        'generic',
        'bingo',
        'proactol',
        'leptin',
        'ambien' ,
        'bigger',
        'Forex',
        'paris',
        'blackjack',
        'proactol',
        'www',
        'kasino',
        'pharma',
        'renova',
        'abilify',
        'shit',
        'fuck',
        'cunt',
        'cocksucker',
        'piss',
        'bukake'
    );
//    $diglc_bad_words = get_option('diglc_bad_words',$bad_words);
    //$diglc_bad_words = $bad_words;
    $diglc_max_requests = get_option('diglc_max_requests',5);
    $diglc_max_timeout = get_option('diglc_max_timeout',10000);
    $diglc_max_timeout_c = $diglc_max_timeout / 1000;
    $diglc_form_field = array(
        'first_name','last_name','email','phone'
    );
    $diglc_form_field = get_option('diglc_form_field',$diglc_form_field);
    $diglc_form_field_name = array(
        'First Name','Last Name','Email','Phone'
    );
    $diglc_form_field_name = get_option('diglc_form_field_name',$diglc_form_field_name);
    //print_r( $diglc_form_field_name);
   // die();
    $diglc_form_field_type = array(
        'text','text','text','text'
    );
    $diglc_form_field_type = get_option('diglc_form_field_type',$diglc_form_field_type);
    $diglc_form_field_required = array(
        'required','required','required','required'
    );
    $diglc_form_field_required = get_option('diglc_form_field_required',$diglc_form_field_required);
    $diglc_form_field_typev = array(
        'none','none','vemail','phone'
    );
    $diglc_form_field_typev = get_option('diglc_form_field_typev',$diglc_form_field_typev);
    
//AIzaSyA_Ki9V3AocNcT7dakpaYVX92h_RGjFhTE
    $settings = get_option('wwhomevalue_settings');

  

    if ('' == $settings) {
            $settings = array (
            'page_title'=>'Seller Home Evaulation', 
            'header' => 'Instant Home Value',
            'header2' => 'Enter Your Address Below To Find Out Now:',
            'mapapi' => '',
            'placeholder'=>'Enter your address',
            'button_text'=>'Get Estimate',
            'map_text'=>'We Found Your Property At:',
            'bg_image'=>  get_bloginfo('url').'/wp-content/plugins/wwhomevalue/includes/images/cma_report_bg.jpg',
            'social_image'=> get_bloginfo('url').'/wp-content/plugins/wwhomevalue/includes/images/cma_report_fb_image.jpg',
            'contact_title'=>'',
            'contact_form_fields'=>'',
            'yes_button'=>'Search Again',
            'contact_button'=>'Send Me My Value!',
            'meta_desc'=>'Find Out What Your Home Is Worth for FREE!',
            'contact_header'=>'Where should we send your evaluation?',
            'styles'=>'default.css',
            'font'=>'default.css'
        );
    }
?>
<div id="plugin_wrapper">
    <form method="post" action="options.php">
        <?php settings_fields( 'wwhomevalue' ); ?>
        <?php submit_button(); ?>
        <div class="acc" id="instructions">
                Instructions
        </div>
        <div class="instructions hidden">
            <h2>
                Instructions
            </h2>
            <p>Copy and add the following shortcode to any page to add the home evaluation form to your website. <b>[address_autocomplete_code]</b></p><br><br>
            <p>
                <ol>
                   <li>
                        Fill in the "Header Text Settings" as you want them to appear on your website.
                   </li><br>
                   <li>
                        Google now requires the use of an API key in order to display maps properly on your website. You can find instructions on obtaining a Google Maps API Key <a href="https://www.weeboweb.com/client-portal/?rp=/knowledgebase" target="_blank">HERE</a>.<br>Once you obtain your API key, enter in the "Google Maps API" Key section.
                   </li><br>
                   <li>
                        Add the image and maeta description you want to show up when the page is shared on social media in the "Social Media Settings."
                   </li><br>
                   <li>
                        Add the image and maeta description you want to show up when the page is shared on social media in the "Social Media Settings."
                   </li><br>
                   <li>
                        Under "Design Settings" you can set the font color, button background color and button text color for your home evaluation plugin. 
                   </li><br>
                   <li>
                        The last step is set up the fields and contact email for the form part of the home evaluation plugin. This must be set up in order for the plugin to send emails when registrations are made. THis plugin utilizes your wordpress websites email sending protocols. Using an SMTP plugin to send will make sure your emails are not sent to junk. We recommend using an SMTP plugin to send mail in conjuction with this plugin. 
                   </li><br>
                </ol>
            </p>
        </div>
        <div class="acc" id="text_settings">
                Header Text Settings
        </div>
        <div class="text_settings hidden">
            <table id="text_table">
                <tr>
                    <td class="left">
                        Page Title  
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[page_title]" value="<?=$settings['page_title']?>" />
                        <br />
                        (This will display within the header of the document and will be what will be seen on Social Media and Search Engines)
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Main Header   
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[header]" value="<?=$settings['header']?>" />
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Sub Header
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[header2]" value="<?=$settings['header2']?>" />
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Search Placeholder 
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[placeholder]" value="<?=$settings['placeholder']?>" />
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Button Text
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[button_text]" value="<?=$settings['button_text']?>" />
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Map Text
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[map_text]" value="<?=$settings['map_text']?>" />
                        <br />
                        ( Note: This will automatically have the searched address below it )
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Contact Button
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[contact_button]" value="<?=$settings['contact_button']?>" />
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Contact Header
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[contact_header]" value="<?=$settings['contact_header']?>" />
                    </td>
                </tr>
            </table>
        </div>
        <div class="acc" id="mapapikey_settings">
                Google Maps API Key
        </div>
        <div class="mapapikey_settings hidden">
            <table id="mapapikey_table">
                <tr>
                    <td class="left">
                        Google Maps API Key
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings['mapapi']" value="<?=$settings["'mapapi'"]?>" />
                    </td>
                </tr>				 <tr>                    <td class="left">                        Google Maps API Key                    </td>                    <td class="right">                        <input type="number" name="wwhomevalue_settings[mapzoom]" value="<?=$settings['mapzoom']?>" />                    </td>                </tr>
                
            </table>
        </div>
        
         <div class="acc" id="social_settings">
                Social Media Settings
        </div>
        <div class="social_settings hidden">
            <table id="social_table">
                <tr>
                    <td class="left">
                        Social Media Thubnail
                        <br />
                        <button class="wp_ml_select_photo" data-target="#social_image" data-thumb-target="#social_image_thumb" >Change Image</button>
                    </td>
                    <td class="right">
                        <img src="<?=$settings['social_image']?>" id="social_image_thumb" />
                        <input type="hidden" name="wwhomevalue_settings[social_image]" value="<?=$settings['social_image']?>" id="social_image" />
                        <br />
                        ( Note - This image must be 200px x 200px to show up correctly on Facebook and must be a .JPG or .PNG )
                    </td>
                </tr>
                <tr>
                    <td class="left">
                        Meta Description  
                    </td>
                    <td class="right">
                        <input type="text" name="wwhomevalue_settings[meta_desc]" value="<?=$settings['meta_desc']?>" />
                        <br />
                        Description of your website that will be displayed on Social Media and Search Engines
                    </td>
                </tr>
            </table>
        </div>
        <div class="acc" id="design_settings">
                Design Settings
        </div>
        <div class="design_settings hidden">
            <table id="design_table">
                 <tr>
                    <td class="left">
                        Headers Font Text Color
                    </td>
                    <td class="right">
                        <input class="mct-color-field" type="text" name="wwhomevalue_settings[headersfont_txtcolor]" value="<?=$settings['headersfont_txtcolor']?>" data-default-color="#ffffff" />
                        
                    </td>
                </tr>                 <tr>
                    <td class="left">
                        Button Background Color
                    </td>
                    <td class="right">
                        <input class="mct-color-field" type="text" name="wwhomevalue_settings[button_bg]" value="<?=$settings['button_bg']?>" data-default-color="#2543ea" />
                        
                    </td>
                </tr>
                 <tr>
                    <td class="left">
                        Button Text color
                    </td>
                    <td class="right">
                        <input class="mct-color-field" type="text" name="wwhomevalue_settings[button_txtcolor]" value="<?=$settings['button_txtcolor']?>" data-default-color="#ffffff" />
                        
                    </td>
                </tr>
            </table>
        </div>
        <div class="acc" id="contact_form_settings">
                Contact Form Settings
        </div>
        <div class="contact_form_settings hidden">
            <h3>Email Settings</h3>
            <div class="section add_email">
                <table id="email_table">
                    <?php $diglc_destination_emails = get_option('diglc_destination_emails');
                    if (is_array($diglc_destination_emails)) {
                        foreach ($diglc_destination_emails as $row) {?>
                    <tr>
                        <td class="email_address">
                            <input type="text" name="diglc_destination_emails[]" class="diglc_destination_emails" value="<?=$row?>" />
                        </td>
                        <td>
                            <div class="remove_email button">Remove</div>
                        </td>
                    </tr>
                    <?php }
                    }?>
                </table>
                <div class="add_new_email button fltleft">Add New Email</div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <h3>Email Message Settings</h3>
            <div class="section email_message_settings">
                <table>
                    <tr>
                        <td>
                            Subject
                        </td>
                        <td>
                            <input type="text" name="diglc_subject" value="<?=get_option('diglc_subject','Message from Customer')?>" />
                        </td>
                    </tr>
					<tr>
                        <td>
                            Redirect Url
                        </td>
                        <td>
                            <input type="text" name="diglc_redirecturl" value="<?=get_option('diglc_redirecturl',site_url())?>" />
                        </td>
                    </tr>
                </table>
                <table id="form_fields">
                    <?php
                    foreach($diglc_form_field_name as $key => $value) {
                        ?>
                        <tr>
                            <td>
                                <input type="text" name="diglc_form_field_name[]" value="<?=$diglc_form_field_name[$key]?>" />
                            </td>
                            <td>
                                <select name="diglc_form_field_type[]">
                                    <option value="text" <?=($diglc_form_field_type[$key] == 'text' ? 'selected="selected"' : '')?>>Input Text</option>
                                    <option value="textarea" <?=($diglc_form_field_type[$key] == 'textarea' ? 'selected="selected"' : '')?>>Text Area</option>
                                    <!--<option value="select" <?=($diglc_form_field_type[$key] == 'select' ? 'selected="selected"' : '')?>>Option Drop-Down</option>-->
                                    <option value="checkbox" <?=($diglc_form_field_type[$key] == 'checkbox' ? 'selected="selected"' : '')?>>Checkbox</option>
                                </select>
                            </td>
                            <td>
                                <select name="diglc_form_field_required[]">
                                    <option value="" <?=($diglc_form_field_required[$key] == '' ? 'selected="selected"' : '')?>>Not Required</option>
                                    <option value="required" <?=($diglc_form_field_required[$key] == 'required' ? 'selected="selected"' : '')?>>Required</option>
                                </select>
                            </td>
                            <td>
                                <select name="diglc_form_field_typev[]">
                                    <option value="" <?=($diglc_form_field_typev[$key] == '' ? 'selected="selected"' : '')?>>Basic Text</option>
                                    <option value="phone" <?=($diglc_form_field_typev[$key] == 'phone' ? 'selected="selected"' : '')?>>Phone Number</option>
                                    <option value="vemail" <?=($diglc_form_field_typev[$key] == 'vemail' ? 'selected="selected"' : '')?>>Email Address</option>
                                </select>
                            </td>
                            <td>
                                <div class="remove_cfield button">Remove</div>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
                <div class="add_new_cfield button fltleft">Add New Form Field</div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <div <?php
            $current_user =  wp_get_current_user();
            if ($current_user->data->user_login != 'dig') { echo ' style="display:none" ';}
            ?>>
                <h3>Spam Words</h3>
                <div class="section ">
                    <div id="add_spamwords">
                        <?php 
                        if (is_array($diglc_bad_words)) {
                            foreach ($diglc_bad_words as $row) {?>
                            <div class="fltleft" class="bad_word">
                                <input type="text" name="diglc_bad_words[]" class="diglc_bad_words" value="<?=$row?>" />
                                <div class="remove_badword button">Remove</div>
                            </div>
                        <?php }
                        }?>
                    </div>
                    <br />
                    <div class="clear"></div>
                    <div class="add_new_badword button fltleft">Add New Word</div>
                </div>
                <br />
                <div class="clear"></div>
                <h3>Throttle</h3>
                <div class="section add_spamwords">
                    <table>
                        <tr>
                            <td>
                                Max requests per session:
                            </td>
                            <td>
                                <input type="text" name="diglc_max_requests" value="<?=$diglc_max_requests?>" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Min time between requests:
                            </td>
                            <td>
                                <input type="text" id="diglc_max_timeout_c" value="<?=$diglc_max_timeout_c?>" /> seconds
                                <input type="hidden" id="diglc_max_timeout" name="diglc_max_timeout" value="<?=$diglc_max_timeout?>" />
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="clear"></div>
        <br />
            <div class="clear"></div>
        <?php submit_button(); ?>
    </form>
    
</div>
<script>
    (function ( $ , window , document , undefined) {
	$(document).ready(function(){
       
        
            $('#diglc_max_timeout_c').keyup(function(){
                $('#diglc_max_timeout').val($(this).val() * 1000);
            });
            // Click Events for Plugin Options
            $('#plugin_wrapper').on("click",'.add_new_email',function() {
                var tr = document.createElement("tr");
                var td = document.createElement("td");
                $(td).attr("class","email_address");
                var input = document.createElement("input");
                $(input).attr("type","text");
                $(input).attr("name","diglc_destination_emails[]");
                $(input).attr("class","diglc_destination_emails");
                $(td).append(input);
                $(tr).append(td);
                var td = document.createElement("td");
                var div = document.createElement("div");
                $(div).attr("class","remove_email button");
                $(div).html("Remove");
                $(td).append(div);
                $(tr).append(td);
                $('#email_table').append(tr);
            });
            $('#plugin_wrapper').on("click",'.remove_email',function() {
                $(this).closest("tr").remove();
            });
            $('#plugin_wrapper').on("click",'.add_new_cfield',function() {
                var tr = document.createElement("tr");
                var td = document.createElement("td");
                 $(td).attr("class","cfield");
                  var input = document.createElement("input");
                  $(input).attr("type","text");
                  $(input).attr("name","diglc_form_field_name[]");
                  $(input).attr("class","diglc_form_field_name");
                 $(td).append(input);
                $(tr).append(td);
                var td = document.createElement("td");
                 var select = document.createElement("select");
                 $(select).attr("name","diglc_form_field_type[]");
                 var option = document.createElement("option");
                  $(option).attr("value","text");
                  $(option).html("Input Text");
                 $(select).append(option);
                 var option = document.createElement("option");
                  $(option).attr("value","textarea");
                  $(option).html("Text Area");
                 $(select).append(option);/*
                 var option = document.createElement("option");
                  $(option).attr("value","select");
                  $(option).html("Option Drop-Down");
                 $(select).append(option);*/
                 var option = document.createElement("option");
                  $(option).attr("value","checkbox");
                  $(option).html("Checkbox");
                 $(select).append(option);
                $(td).append(select);
                $(tr).append(td);
                var td = document.createElement("td");
                 var select = document.createElement("select");
                 $(select).attr("name","diglc_form_field_required[]");
                 var option = document.createElement("option");
                  $(option).attr("value","");
                  $(option).html("Not Required");
                 $(select).append(option);
                 var option = document.createElement("option");
                  $(option).attr("value","required");
                  $(option).html("Required");
                 $(select).append(option);
                $(td).append(select);
                $(tr).append(td);
                var td = document.createElement("td");
                 var select = document.createElement("select");
                 $(select).attr("name","diglc_form_field_typev[]");
                 var option = document.createElement("option");
                  $(option).attr("value","");
                  $(option).html("Basic Text");
                 $(select).append(option);
                 var option = document.createElement("option");
                  $(option).attr("value","phone");
                  $(option).html("Phone Number");
                 $(select).append(option);
                 var option = document.createElement("option");
                  $(option).attr("value","vemail");
                  $(option).html("Email Address");
                 $(select).append(option);
                $(td).append(select);
                $(tr).append(td);
                var td = document.createElement("td");
                 var div = document.createElement("div");
                 $(div).attr("class","remove_cfield button");
                 $(div).html("Remove");
                 $(td).append(div);
                $(tr).append(td);
                $('#form_fields').append(tr);
            });
            $('#plugin_wrapper').on("click",'.remove_cfield',function() {
                $(this).closest("tr").remove();
            });
            $('#plugin_wrapper').on("click",'.add_new_badword ',function() {
                var div = document.createElement("div");
                $(div).attr("class","fltleft");
                var input = document.createElement("input");
                $(input).attr("type","text");
                $(input).attr("name","diglc_bad_words[]");
                $(input).attr("class","diglc_bad_words");
                $(div).append(input);
                var button = document.createElement("div");
                $(button).attr("class","remove_badword button");
                $(button).html("Remove");
                $(div).append(button);
                $('#add_spamwords').append(div);
            });
            $('#plugin_wrapper').on("click",'.remove_badword',function() {
                $(this).parent().remove();
            });
            $('.acc').on("click",function(){
                var c = '.'+$(this).attr("id");
                $(c).toggle("fast");
 
            });
        });
} ( jQuery , window, document));
</script>