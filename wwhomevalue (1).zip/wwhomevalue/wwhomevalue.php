<?php
/*
Plugin Name: wwHomeValue
Description: Home seller lead capture tool for real estate estate agents.
Version:  1.0.9
Author: WeeboWeb
Author URI: https://WeeboWeb.com
License: GPL2
*/



ini_set('display_errors',1);
$path = preg_replace( '/wp-content(?!.*wp-content).*/', '', __DIR__ );
require_once( $path . 'wp-load.php' );

require_once('wp-updates-plugin.php');
new WPUpdatesPluginUpdater_1510( 'http://wp-updates.com/api/2/plugin', plugin_basename(__FILE__));


// install
if (strpos(get_stylesheet_directory(),'dig_theme3') !== false) {
    $theme_path = ABSPATH.'/wp-content/plugins/dig-widget/layouts/dig_theme3';
}else{
    $theme_path = get_stylesheet_directory();
}
if (!file_exists($theme_path.'/t-wwhomevalue.php')) {
    copy(ABSPATH.'/wp-content/plugins/wwhomevalue/includes/docs/t-wwhomevalue.php' , $theme_path."/t-wwhomevalue.php");
}
$digl_session;
$digl_classContainer;
if(empty(get_option('diglc_form_field_typev'))){
    add_option('diglc_form_field_typev',maybe_unserialize('a:4:{i:0;s:0:"";i:1;s:0:"";i:2;s:6:"vemail";i:3;s:5:"phone";}'));
}
if(empty(get_option('diglc_form_field_required'))){
    add_option('diglc_form_field_required',maybe_unserialize('a:4:{i:0;s:8:"required";i:1;s:8:"required";i:2;s:8:"required";i:3;s:8:"required";}'));
}
if(empty(get_option('diglc_form_field_type'))){
    add_option('diglc_form_field_type',maybe_unserialize('a:4:{i:0;s:4:"text";i:1;s:4:"text";i:2;s:4:"text";i:3;s:4:"text";}'));
}
if(empty(get_option('diglc_form_field_name'))){
    add_option('diglc_form_field_name',maybe_unserialize('a:4:{i:0;s:10:"First Name";i:1;s:9:"Last Name";i:2;s:5:"Email";i:3;s:5:"Phone";}'));
}


if(empty(get_option('diglc_mapapikey'))){

   add_option('diglc_mapapikey',maybe_unserialize('a:4:{i:0;s:10:"First Name";i:1;s:9:"Last Name";i:2;s:5:"Email";i:3;s:5:"Phone";}'));


}
if(empty(get_option('diglc_destination_emails'))){
  add_option('diglc_destination_emails',maybe_unserialize('a:1:{i:0;s:24:"dgiusti@digmarketing.com";}'));
}
if(empty(get_option('diglc_subject'))){
    add_option('diglc_subject','Lead From WeeboWeb Seller Form');
}
//add_filter('wp_mail_from', 'mail_from');
add_filter('wp_mail_from_name', 'mail_from_name');
 
function mail_from() {
  return 'support@weeboweb.com';
}
function mail_from_name() {
 return 'WeeboWeb';
}

function wwhomevalue_construct()
{
  require plugin_dir_path( __FILE__ ) . 'includes/functions/contact_functions.php';


    global $wpdb;
    include_once('includes/sql/install.php');
    global $digl_classContainer;
    global $digl_session;
    if(!class_exists('dig_General'))require_once('includes/classes/dig_General.class.php');
    if(!class_exists('dig_Session'))require_once('includes/classes/dig_session.model.class.php');
    // init Global Classes 
    $digl_classContainer['general'] = new dig_General();
    $digl_classContainer['session'] = new dig_Session($wpdb);
    $digl_session = $digl_classContainer['session']->mdl_setSession();
    
}
add_action ('admin_init', 'register_wwhomevalue_settings');
function register_wwhomevalue_settings() {
    register_setting ('wwhomevalue', 'wwhomevalue_settings');
    register_setting ('wwhomevalue', 'diglc_destination_emails');
    register_setting ('wwhomevalue', 'diglc_subject');
    register_setting ('wwhomevalue', 'diglc_redirecturl');
    register_setting ('wwhomevalue', 'diglc_form_field_name');
    register_setting ('wwhomevalue', 'diglc_form_field_type');
    register_setting ('wwhomevalue', 'diglc_form_field_required');
    register_setting ('wwhomevalue', 'diglc_form_field_typev');
     global $wpdb;
  
  if ( null === $wpdb->get_row( "SELECT post_name FROM {$wpdb->prefix}posts WHERE post_name = 'mct-map'", 'ARRAY_A' ) ) {
     
    $current_user = wp_get_current_user();
   // print_r($current_user);
    
    // create post object
    $page = array(
      'post_title'  => __( 'Mct Map' ),
      'post_status' => 'publish',
      'post_author' => $current_user->ID,
      'post_type'   => 'page',
    );
    
    // insert the post into the database
    wp_insert_post( $page );
  }
    
}
add_action ('admin_menu', 'wwhomevalue_plugin_menu');
function wwhomevalue_plugin_menu() {
    add_menu_page( 'wwHomeValue', 'wwHomeValue', 'manage_options', 'wwhomevalue-settings', 'wwhomevalue_settings');
}
function wwhomevalue_settings()
{
    if ( !current_user_can( 'manage_options' ) )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }
    wp_enqueue_media();
    wp_register_script( 'wpMedia', plugins_url("includes/js/jquery.medialibrary.js",__FILE__ ), array(), false, false );
    wp_enqueue_script( 'wpMedia' );
    include ('includes/docs/wwhomevalue_settings.php');
}
function wwhomevalue_uninstall() {
    if (strpos(get_stylesheet_directory(),'dig_theme3') !== false) {
        $theme_path = ABSPATH.'/wp-content/plugins/dig-widget/layouts/dig_theme3';
    }else{
       $theme_path = get_stylesheet_directory();
    }
    @unlink( $theme_path."/t-wwhomevalue.php" );
    global $wpdb;
    $table_name = 'dig_session';
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql);
    
    delete_option( 'diglc_destination_emails' );
    delete_option( 'diglc_subject' );
    delete_option ('diglc_redirecturl');
    delete_option( 'diglc_form_field_name' );
    delete_option( 'diglc_form_field_type' );
    delete_option( 'diglc_form_field_required' );
    delete_option( 'diglc_form_field_required' );
    delete_option( 'diglc_form_field_typev' );
    delete_option( 'ww_home_value_settings' );
    delete_option( 'wwhomevalue_settings' );
}
register_uninstall_hook( __FILE__, 'wwhomevalue_uninstall' );
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'setting_links' );
function setting_links( $links ) {
   $links[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=wwhomevalue-settings') ) .'">Settings</a>';
   return $links;
}

 function wwhomevalue_export_result($message = '')

{
   
    header('Content-Type: application/json');
    echo json_encode(array('success'=>1,'message'=>$message));
    
    wp_die(); 
}

function wwhomevalue_sendmessage()
{
    wwhomevalue_construct();
 
    global $errors;
    global $digl_classContainer;
    global $digl_session;
require plugin_dir_path( __FILE__ ) . 'includes/functions/contact_functions.php';


_digl_sendmessage();
 wwhomevalue_export_result();
    if(false !== _digl_sendmessage()) {
   wwhomevalue_export_result();
    } else {
        $errors[] = "Something test didn't work";
        wwhomevalue_display_errors();
    } 
}
/*****
 * @method dig_display_errors()
 * @description : Gathers errors from local and classes then builds JSON and dumps a successful result
 * @return : void ( exports JSON )
 */
function wwhomevalue_display_errors($ajax = true)
{
    global $digl_classContainer;
    global $errors;
    foreach ($digl_classContainer as $row) {
//        if ($row->has_error()) {
//            $errors[] = $row->get_error_message();  
//        }
    }
    if (false === $ajax) {
        echo '<h3>Some test errors occured:</h3><pre>';print_r($errors);exit();
    }else{
        header('Content-Type: application/json');
        echo json_encode(array('success'=>0,'error'=>$errors));
        wp_die();
    }
}
/*****
 * @method dig_export_result()
 * @description : buils JSON and dumps a successful result
 * @return : void ( exports JSON )
 */


function dig_sendmessage(){
    wwhomevalue_construct();
    global $errors;
    global $digl_classContainer;
    global $digl_session;
   require plugin_dir_path( __FILE__ ) . 'includes/functions/contact_functions.php';

//wwhomevalue_export_result();
   //  die();
     if(false !== _digl_sendmessage()) {
         
  wwhomevalue_export_result();
    } 
    else {
        $errors[] = "Something didn't work";
        wwhomevalue_display_errors();
    } 
}
/*****
 * @method dig_wp_ajax()
 * @description : handles the ajax call and passes to the method requested
 * @return : void 
 */
function digl_wp_ajax(){
die('working');
 
   wwhomevalue_construct();
    global $digl_classContainer;
    global $errors;
    
    $method = $digl_classContainer['general']->get_request('method',false);
    if (false !== $method) {
        if (function_exists($method)) {
            $method();
        } else {
            $errors[] = "Method does not exist";
            wwhomevalue_display_errors();
        }
    }
}
add_action( 'wp_ajax_digl_wp_ajax', 'digl_wp_ajax' );
 add_action( 'wp_ajax_nopriv_digl_wp_ajax', 'digl_wp_ajax' );
add_filter( 'page_template', 'wpa3396_page_template' );
function wpa3396_page_template( $page_template )
{
    if ( is_page( 'mct-map' ) ) {
        $page_template = dirname( __FILE__ ) . '/templates/mct-map.php';
    }
    return $page_template;
}
// function that runs when shortcode is called

function mct_address() { 
ob_start(); 
$settings = get_option('wwhomevalue_settings');
 $diglc_mapapikey = $settings["'mapapi'"];
if ('' == $settings) {
    $settings = array (
            'page_title'=>'Seller Home Evaulation', 
            'header' => 'Instant Home Value',
            'header2' => 'Enter Your Address Below To Find Out Now:',
            'mapapi' => '',
            'placeholder'=>'Enter your address',
            'button_text'=>'Get Estimate',
            'map_text'=>'We Found Your Property At:',
            'bg_image'=>  get_bloginfo('url').'/wp-content/plugins/wwhomevalue/includes/images/cma_report_bg.jpg',
            'social_image'=> get_bloginfo('url').'/wp-content/plugins/wwhomevalue/includes/images/cma_report_fb_image.jpg',
            'contact_title'=>'',
            'contact_form_fields'=>'',
            'yes_button'=>'Search Again',
            'contact_button'=>'Send Me My Value!',
            'meta_desc'=>'Find Out What Your Home Is Worth for FREE!',
            'contact_header'=>'Where should we send your evaluation?',
            'styles'=>'default.css',
            'font'=>'default.css'
        );
}
echo '<style>   
input#prop-address {
    width: 100% !important;
}   
    
#form_container{
    width:70%;
    margin:0 auto;
}
#form_container h1 {
    
    text-align: center;
    padding: 0px 0px 40px 0px;
}
#form_container h2 {
    
    text-align: center;
    padding: 0px 0px 40px 0px;
}
.cta-wrap {
    max-width: 40rem;
    margin: 3rem 0 2rem;
    position: relative;
    z-index: 1;
    text-align: left;
    margin-bottom: 0px;
}
.cta-wrap input {
    border-radius: 0.8rem!important;
    font-size: 1rem!important;
    padding-left: 2.45rem!important;
    height: 3.8rem!important;
    background: white!important;
    border: none!important;
    box-shadow: 0 13px 26px rgb(0 0 0 / 12%);
}
.cta-wrap .button {
    height: 2.8rem!important;
    line-height: 1.6rem;
    position: absolute;
    right: 0.8rem;
    top: 0.5rem;
    border-radius: 0.6rem!important;
    margin: 0;
    font-size: 1rem!important;
    font-weight: bold;
        
    box-shadow: 0.1rem 0.3rem 0.5rem rgb(0 0 0 / 10%);
    color: white;
    outline: 0;
   
    
}
.default-seller {
    max-width: 100%;
    text-transform: none!important;
}
.default-seller-subheading {
    max-width: 100%;
    text-shadow: 0 0 1rem rgb(0 0 0 / 60%);
    text-transform: none!important;
}
.logo-items{
    margin-right:5px;
}
img.jeff-logo-items {
    width: 120px;
}
img.jeff-logo-items {
    width: 120px;
}
.top-images-jeff {
    display: inline-flex;
   align-items: end;
}
.jeff-text {
    margin-left: 10px;
    position: relative;
    top: 7px;
}
.phn{
   
    text-align:center;
}
a.mobile-number-jeff:hover {
    text-decoration: none;
    color:#fff;
}
a.mobile-number-jeff {
    color: #ffffff;
}
.logo-item{
        width: 243px;
}
@media screen and (max-width: 800px) {
 .cta-wrap {
    width:100%;
    margin:0 auto;
}
img.logo-items {
    width: 76px;
}
.phn {
    width: 100%;
    margin: 0 auto;
    right: 0!important;
}
}
    </style>';
    echo '<script>
let autocomplete;
let address1Field;
let address2Field;
let postalField;


function initAutocomplete() {
  address1Field = document.querySelector("#prop-address");
  
  // Create the autocomplete object, restricting the search predictions to
  // addresses in the US and Canada.
  autocomplete = new google.maps.places.Autocomplete(address1Field, {
    componentRestrictions: { country: ["us", "ca"] },
    fields: ["address_components", "geometry"],
    types: ["address"],
  });
  address1Field.focus();
  // When the user selects an address from the drop-down, populate the
  // address fields in the form.
  autocomplete.addListener("place_changed", fillInAddress);
}

function fillInAddress() {
  // Get the place details from the autocomplete object.
  const place = autocomplete.getPlace();
 
console.log(place);
  // Get each component of the address from the place details,
  // and then fill-in the corresponding field on the form.
  // place.address_components are google.maps.GeocoderAddressComponent objects
  // which are documented at http://goo.gle/3l5i5Mr
  for (const component of place.address_components) {
    const componentType = component.types[0];
    switch (componentType) {
      case "street_number": {
        address1 = `${component.long_name} ${address1}`;
        break;
      }

      case "route": {
        address1 += component.short_name;
        break;
      }
  }
  }
 
  address1Field.focus();
}
</script>';
echo '<script
      src="https://maps.googleapis.com/maps/api/js?key='.$diglc_mapapikey.'&callback=initAutocomplete&libraries=places&v=weekly"
      async
    ></script>';
echo '<div class="content"><div class="top-images-jeff"><img class="jeff-logo-items" src="'.plugin_dir_url( __FILE__ ).'images/big pic jeff and kari.jpg"><div class="jeff-text"><img class="logo-item" src="'.plugin_dir_url( __FILE__ ).'images/logo blue.jpg"></div></div><h1 class="title default-seller" style="color:'.$settings['headersfont_txtcolor'].'!important">'.$settings['header'].'</h1><h2 class="default-seller-subheading" style="color:'.$settings['headersfont_txtcolor'].'!important">'.$settings['header2'].'</h2><div class="cta-wrap"><form id="address-form" action="/mct-map/" method="get" autocomplete="off"><input id="prop-address" name="prop-address" placeholder="'.$settings['placeholder'].'" type="text"><ul class="mb_ac"></ul><input style="background-color:'. $settings['button_bg'].'!important;color:'.$settings['button_txtcolor'].'!important" class="button" id="place-search-button" type="submit" value="'.$settings['button_text'].'"></form></div></div>';
 echo '<div style="width: 120px;display: inline-flex;" class="logos"><img class="logo-items" src="'.plugin_dir_url( __FILE__ ).'images/Best Of 2019 favorite logo.png"><img class="logo-items" src="'.plugin_dir_url( __FILE__ ).'images/new favor.jpg"><img class="logo-items" src="'.plugin_dir_url( __FILE__ ).'images/Best of 2017 FAVE.jpg"><img class="logo-items" src="'.plugin_dir_url( __FILE__ ).'images/Old Miramar Logo (1).jpg"></div><div class="phn" style="color:white;text-align:center;font-size: 40px; position: relative;
 right: 26px;margin-top: 9px;"><a class="mobile-number-jeff" href="tel:661-703-9800">661-703-9800</a></div>';

 $output = ob_get_clean();
    return $output;
} 
// register shortcode
add_shortcode('address_autocomplete_code', 'mct_address'); 
add_action( 'admin_enqueue_scripts', 'mw_enqueue_color_picker' );
function mw_enqueue_color_picker( $hook_suffix ) {
    // first check that $hook_suffix is appropriate for your admin page
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'my-script-handle', plugins_url('includes/js/mctcolor-script.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
}

function send_email($data)



{



    global $errors;



    global $digl_classContainer;



    global $digl_session;



    



    if (isset($digl_session['contact']['sample_ip'])) {



        if ($_SERVER['REMOTE_ADDR'] == $digl_session['contact']['sample_ip']) {



            if ( (int)$digl_session['contact']['requests'] > get_option('diglc_max_requests',5) ) {



                $errors[] = 'maximum requesrs for a given period reached...try again in 10 minutes';



                return false;



            }



            $sample = "-".(get_option('diglc_max_timeout',3000) / 1000)." second";



            if ($digl_session['contact']['sample_time'] > date('Y-m-d H:i:s',strtotime($sample)) ) {



                $errors[] = 'maximum requesrs for a given period reached...try again in '.(get_option('diglc_max_timeout',3000) / 1000).' seconds';



                return false;



            }



        }



    }



    if (isset($digl_session['contact']['requests'])) {



        $rfq = (int)$digl_session['contact']['requests'];



        $rfq++;



    }else{



        $rfq = 1;



    }



    $params = array(



        'init' => 1,



        'contact' => array(



            'sample_ip' => $_SERVER['REMOTE_ADDR'],



            'requests' => $rfq,



            'sample_time' => date('Y-m-d H:i:s')



        )



    );



    $digl_session = $digl_classContainer['session']->mdl_setSession($params);



    return true;



}
add_action('init','email_send_function');
function email_send_function(){
    // $required = get_option('diglc_form_field_required');
    // if($required[1] == 'required'){
    //     if(empty($_POST['first_name'])){
    //        return false;
    //     }
    // }
    // if($required[2] == 'required'){
    //     if(empty($_POST['first_name'])){
    //        return false;
    //     }
    // }
    // echo "<pre>";print_r($required);
    // wp_mail('ghavzhva','gshsu','huhsiwh');SS
    echo "<pre>";print_r($_POST);die;
    global $wpdb;
}

add_action( 'wp_ajax_nopriv_email_send_function', 'email_send_function' );
add_action( 'wp_ajax_email_send_function', 'email_send_function' );



?>