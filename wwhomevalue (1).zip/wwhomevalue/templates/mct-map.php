<?php
get_header();
$settings = get_option('wwhomevalue_settings');
$redirectUrl = get_option('diglc_redirecturl');
$diglc_mapapikey = get_option('diglc_mapapikey');
$settings['button_bg'] = 'red';
$settings['button_txtcolor'] = 'black';
if ('' == $settings) {
    $settings = array (
            'page_title'=>'Seller Home Evaulation', 
            'header' => 'Find Out What Your Home Is Worth for FREE!',
            'header2' => 'Enter Your Address Below To Find Out Now:',
            'header3' => '',
            'placeholder'=>'Enter address in following format: Address,City,State,Zip',
            'button_text'=>'Find Out Now',
            'map_text'=>'We Found Your Property At:',
            'bg_image'=>  get_bloginfo('url').'/wp-content/plugins/wwhomevalue/includes/images/cma_report_bg.jpg',
            'social_image'=> get_bloginfo('url').'/wp-content/plugins/wwhomevalue/includes/images/cma_report_fb_image.jpg',
            'contact_title'=>'',
            'contact_form_fields'=>'',
            'yes_button'=>'Search Again',
            'contact_button'=>'Send Me My Value!',
            'meta_desc'=>'Find Out What Your Home Is Worth for FREE!',
            'contact_header'=>'Where should we send your evaluation?',
            'styles'=>'default.css',
            'font'=>'default.css'
        );
}

?>
	<meta charset="UTF-8">
	
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="<?=$settings['meta_desc']?>" />
    <meta property="og:image" content="<?=$settings['social_image']?>" />
    <link rel="stylesheet" href="/wp-content/plugins/wwhomevalue/includes/css/<?php if(isset($settings['style'])){echo $settings['style'];} ?>" />
        <link rel="stylesheet" href="/wp-content/plugins/wwhomevalue/includes/styles/mctcontact.css" />
    <link rel="stylesheet" href="/wp-content/plugins/wwhomevalue/includes/fonts/<?php if(isset($settings['font'])){echo $settings['font'];} ?>" />
	
    <script src="https://maps.googleapis.com/maps/api/js?key=<?=$settings["'mapapi'"]?>&sensor=false"></script>
    <script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
    <script type='text/javascript'>
    /* <![CDATA[ */
    var ajax_object = {"ajaxurl":"/wp-admin/admin-ajax.php"};
    /* ]]> */
    </script>
    <script src="/wp-content/plugins/wwhomevalue/includes/js/jquery.Digl.base.class.js"></script>
    <script src="/wp-content/plugins/wwhomevalue/includes/js/jquery.Digl.mctcontact.js"></script>
    <!--<script src="<?php //echo bloginfo('url'); ?>/wp-content/plugins/wwhomevalue/includes/js/jquery.backstretch.min.js"></script>->
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	
 <style>
 #map_canvas {
ma
  width: 100%;
}
b, strong {
    font-weight: bolder;
    font-size: 24px;
}
.address{
  font-weight: bolder;
    font-size: 40px;
}

.validate{
padding-bottom: 85px;
}
.myButton {
/*	box-shadow:inset 0px 1px 0px 0px #ffffff;
	background:linear-gradient(to bottom, #ffffff 5%, #f6f6f6 100%);
	//background-color:#ffffff;*/
	border-radius:6px;
/*	border:1px solid #dcdcdc;*/
	display:inline-block;
	cursor:pointer;
	/*color:#666666;*/
	font-family:Arial;
	font-size:17px;
	font-weight:bold;
	padding:14px 76px;
	text-decoration:none;
	border: none;
	/*text-shadow:0px 1px 0px #ffffff;*/
}
/*.myButton:hover {
	background:linear-gradient(to bottom, #f6f6f6 5%, #ffffff 100%);
	background-color:#f6f6f6;
}
.myButton:active {
	position:relative;
	top:1px;
}*/
.css-input {
     padding: 5px;
     font-size: 16px;
     border-width: 1px;
     border-color: #CCCCCC;
     background-color: #FFFFFF;
     color: #000000;
     border-style: solid;
     border-radius: 0px;
     box-shadow: 0px 0px 5px rgba(66,66,66,.75);
     text-shadow: 0px 0px 5px rgba(66,66,66,.75);
}
 .css-input:focus {
     outline:none;
}.mct-w{	width:100%!important;}span.err_message {    color: red;}
</style>
<?php function my_enqueue() {

	wp_enqueue_script( 'ajax_custom_script',  plugin_dir_url( __FILE__ ) . '/includes/ajax-javascript.js', array('jquery') );
	wp_localize_script( 'ajax_custom_script', 'ajax_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
}
add_action( 'wp_enqueue_scripts', 'my_enqueue' );
?>
<div class="mct-container">
  <div class="row">
    <div class="col-12 col-sm-6" style="padding-top: 5em; padding-right: 5em; padding-left: 5em; background-color: #223949 !important;color:#fff">
           <h1 class="text-center"><?=$settings['map_text'];?></h1>
           <div class="redirect-url" style="display:none;"><?php echo $redirectUrl;?></div>
		<div id="loc_id" class="text-center" style="color:#EBD567;"></div>
		 <h2 class="text-center"><?=$settings['contact_header'];?></h2>
		 <form method="post">
                    <section class="validate">
                       <div class="row">
                        <?php
                       
                            $diglc_destination_emails = get_option('diglc_destination_emails');

                        
                            if (!empty($diglc_destination_emails)){
                                $diglc_form_field_name = get_option('diglc_form_field_name');
                            }else{
                                $diglc_form_field_name = false;
                            }
                             $diglc_form_field_name = get_option('diglc_form_field_name');
                            if (false === $diglc_form_field_name) {
                                echo "<p>The settings for this form are complete. Please add them in the wwHomeValue Settings.</p>";
                            } else {
                                $diglc_form_field_type = get_option('diglc_form_field_type');
                                $diglc_form_field_required = get_option('diglc_form_field_required');
                              //print_r($diglc_form_field_required);
                                $diglc_form_field_typev = get_option('diglc_form_field_typev');
                                if (is_array($diglc_form_field_name)) {
                                    foreach($diglc_form_field_name as $key => $value) {
                                       
                                     
                                    ?>
                                   
                                        <div class="c1of3 col-sm-3">
                                        <?=ucwords($value)?><?php if ('' !=$diglc_form_field_required[$key] ) {
                                          
                                        echo '<span style="color:red;">*</span>';
                                        } ?>
                                        </div>

                       
                                        <div class="c2of3 col-sm-9">
                                                <?php
                                                switch($diglc_form_field_type[$key]) {
                                                    case 'text':
                                                        echo '<input type="text"
                                                                id="'.strtolower(str_replace(' ','_',$value)).'"
                                                                class="mct-w css-input '.$diglc_form_field_required[$key].' '.$diglc_form_field_typev[$key].'" />';
                                                              // echo $diglc_form_field_required[$key];
                                                        break;
                                                    case 'textarea':
                                                        echo '<textarea data-max="500" id="'.strtolower(str_replace(' ','_',$value)).'"
                                                                class="mct-w css-input '.$diglc_form_field_required[$key].' '.$diglc_form_field_typev[$key].'"></textarea>
                                                                <br /><span class="number_of_chr"></span>';
                                                        break;
                                                    case 'checkbox':
                                                        echo '<input type="checkbox" id="'.strtolower(str_replace(' ','_',$value)).'" />';
                                                        break;
                                                }
                                                if ('' != $diglc_form_field_required[$key] OR
                                                    '' !=$diglc_form_field_typev[$key] ) {
                                                    echo '<span class="err_message"> </span>';
                                                }

                                                
                                                ?>
                                        </div>
                                    
                                        <div class="clear"></div>
                                        <p></p>
                                        <?php 

                                    }
                                } else {
                                ?>
                                    <p>The settings for this form are incomplete. Please add them in the wwHomeValue Settings.</p>
                                    <?php
                                }
                            }
                        ?>
                        </div>
                        <div class="c1of3">
                        
                        </div>
                        <div class="c2of3" style="text-align: center;">
                            <input type="hidden" name="address" id="address" value="" />
                            <button style="background-color:<?php if(isset($settings['button_bg'])){echo $settings['button_bg'];}?>!important;color:<?php if(isset($settings['button_txtcolor'])){echo $settings['button_txtcolor'];}?>!important;" type="button" class="submit_form myButton"><?php if(isset($settings['contact_button'])){echo $settings['contact_button'];} ?></button>
                            
                         
                        </div>
                        
                    </section>
                </form>
    </div>
    <div class="col-12 col-sm-6">
    <div id="map_canvas" ></div>
    </div>
  </div>
</div>

<script>
	function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

    $(document).ready(function(){
    var map_x = decodeURIComponent(getUrlVars()["prop-address"]).replace(/\+/g, " "); 
	$("#loc_id").text(map_x);
   	$("#address").val(map_x);
});
var mapmargin = 0;
$('#map_canvas').css("height", ($(window).height() - mapmargin));
$(window).on("resize", resize);
resize();
function resize(){

    if($(window).width()>=980){
        $('#map_canvas').css("height", ($(window).height() - mapmargin));    
        $('#map_canvas').css("margin-top",0);
    }else{
        $('#map_canvas').css("height", ($(window).height() - (mapmargin+12)));    
        $('#map_canvas').css("margin-top",-21);
    }

}
</script>
<script type="text/javascript">
 var geocoder;
var map;
var address = decodeURIComponent(getUrlVars()["prop-address"]).replace(/\+/g, " ");

var infoWindow = null;
function initialize() {
  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(-34.397, 150.644);
  var myOptions = {
    zoom:  <?=$settings['mapzoom'];?>,
    center: latlng,
    mapTypeControl: true,
    mapTypeControlOptions: {
      style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    },
    navigationControl: true,
    mapTypeId: 'terrain'
  };
  map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
  if (geocoder) {
    geocoder.geocode({
      'address': address
    }, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
          map.setCenter(results[0].geometry.location);
          map.setZoom(<?=$settings['mapzoom'];?>);
        
		 var marker = new google.maps.Marker({
               position: results[0].geometry.location,
               map: map,
               //draggable:true,
			    title: address
              
            });


          var infowindow = new google.maps.InfoWindow({
               content:'<b>'+ address + '</b>',
			  // size: new google.maps.Size(100, 30)
            });
				
            infowindow.open(map,marker);

        } else {
          alert("No results found");
        }
      } else {
        alert("Geocode was not successful for the following reason: " + status);
      }
    });
  }
}
google.maps.event.addDomListener(window, 'load', initialize);
</script>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<?php get_footer();?>