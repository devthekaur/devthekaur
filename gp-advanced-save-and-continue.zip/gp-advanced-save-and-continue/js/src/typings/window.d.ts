import type { GPAdvancedSaveAndContinue, createGPAdvancedSaveAndContinue } from '../gp-advanced-save-and-continue';
import type { DraftManagement } from '../draft-management';

/**
 * Augment Window typings and add in properties provided by Gravity Forms, WordPress, etc.
 */

declare global {
	interface Window {
	    jQuery: JQueryStatic;
	    GPPS_AJAX_URL: string;
	    GPPS_NONCE: string;
		GPPA: {
			AJAXURL: string;
		};
		createGPAdvancedSaveAndContinue: typeof createGPAdvancedSaveAndContinue;
		GPAdvancedSaveAndContinue: typeof GPAdvancedSaveAndContinue;
		GPAdvancedSaveAndContinueDraftManagement: typeof DraftManagement;
		gform: {
			doAction: (action: string, ...args: any[]) => void;
		}
	}
}
