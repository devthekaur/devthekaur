<?php
/**
 * @author  wpWax
 * @since   6.7
 * @version 7.0.8
 */
?>

<div class="directorist-listing-card-zip"><?php directorist_icon( $icon ); ?><span class="directorist-listing-single__info--list__label"><?php $listings->print_label( $label ); ?></span> <?php echo esc_html( $value ); ?></div>