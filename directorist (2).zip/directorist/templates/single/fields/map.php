<?php
/**
 * @author  wpWax
 * @since   6.7
 * @version 7.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="directorist-single-map" data-map="<?php echo esc_attr( $listing->map_data() ); ?>"></div>