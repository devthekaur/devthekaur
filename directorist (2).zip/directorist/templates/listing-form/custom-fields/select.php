<?php
/**
 * @author  wpWax
 * @since   6.6
 * @version 7.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="directorist-form-group directorist-custom-field-select">
    <?php $listing_form->field_label_template($data); ?>
    <?php if (!empty($data['options'])) : ?>
        <select name="<?php echo esc_attr($data['field_key']); ?>" id="<?php echo esc_attr($data['field_key']); ?>" class="directorist-form-element" <?php $listing_form->required($data); ?>>
            <?php $kidsafe_selected = false; // Flag to track if Kidsafe Trained option is selected ?>
            <?php foreach ($data['options'] as $value) : ?>
                <?php if ($value['option_value'] === 'Kidsafe Trained' || ($value['option_value'] === $data['value'])): ?>
                    <option value="<?php echo esc_attr($value['option_value']); ?>" selected="selected">
                        <?php echo esc_html($value['option_label']); ?>
                    </option>
                    <?php if ($value['option_value'] === 'Kidsafe Trained') $kidsafe_selected = true; ?>
                <?php else: ?>
                    <option value="<?php echo esc_attr($value['option_value']); ?>">
                        <?php echo esc_html($value['option_label']); ?>
                    </option>
                <?php endif; ?>
            <?php endforeach; ?>
            <?php // If Kidsafe Trained isn't already selected, add it as selected ?>
            <?php if (!$kidsafe_selected): ?>
                <option value="Kidsafe Trained" selected="selected">Kidsafe Trained</option>
            <?php endif; ?>
        </select>
    <?php endif; ?>
    <?php $listing_form->field_description_template($data); ?>
</div>

