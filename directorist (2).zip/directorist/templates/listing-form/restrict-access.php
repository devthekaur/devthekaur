<?php
/**
 * @author  wpWax
 * @since   6.6
 * @version 6.7
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="directorist-edit-listing-error"><?php esc_html_e( 'You do not have permission to edit this listing', 'directorist' ); ?></div>