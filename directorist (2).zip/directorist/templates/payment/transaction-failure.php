<?php
/**
 * @author  wpWax
 * @since   7.0
 * @version 7.3.1
 */

esc_html_e('Your Transaction was not successful. Please contact support', 'directorist');