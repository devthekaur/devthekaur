<?php
/**
 * Plugin Name: LightAct Elementor Addons
 * Description: Custom addon that adds a "international phone" field to Elementor Forms Widget.
 * Plugin URI:  https://elementor.com/
 * Version:     1.0.0
 * Author:      Elementor Developer
 * Author URI:  https://developers.elementor.com/
 * Text Domain: lightAct-elementor-addons
 *
 * Elementor tested up to: 3.16.0
 * Elementor Pro tested up to: 3.16.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Add new `international-phone` field to Elementor form widget.
 *
 * @since 1.0.0
 * @param \ElementorPro\Modules\Forms\Registrars\Form_Fields_Registrar $form_fields_registrar
 * @return void
 */
// Enqueue Styles
function my_enqueue_styles() {
    wp_enqueue_style('intl-style', plugins_url('build/css/intlTelInput.css', __FILE__), array(), '1.0', 'all');
	 wp_enqueue_style('intl-style1', plugins_url('build/css/demo.css', __FILE__), array(), '1.0', 'all');
}
add_action('wp_enqueue_scripts', 'my_enqueue_styles');

// Enqueue Scripts
function my_enqueue_scripts() {
    wp_enqueue_script('intlTelInput', plugins_url('build/js/intlTelInput.js', __FILE__), array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'my_enqueue_scripts');

function add_new_form_field( $form_fields_registrar ) {

	require_once( __DIR__ . '/form-fields/international-phone.php' );

	$form_fields_registrar->register( new \Elementor_International_Phone_Field() );

}
add_action( 'elementor_pro/forms/fields/register', 'add_new_form_field' );

function intl_tel_input_javascript() {
?>
<style>
.iti {
    position: relative;
    display: inline-block;
    width: 100%;
}
.iti__selected-dial-code{
	display:none;
}
</style>
<script>
jQuery( document ).ready( () => {
 const allInputs = document.querySelectorAll("input[type='international-phone']");

 allInputs.forEach(function(input) {
	 
  var iti = window.intlTelInput(input, {
	  separateDialCode: true,
	  autoPlaceholder: "off",
	  autoInsertDialCode: true,
	    
		 
    utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/utils.js",
  });
    input.addEventListener('blur', function() {
		jQuery(this).val(iti.getNumber());
     // jQuery('input[name="phonewithcountrycode"]').val(iti.getNumber());
    });
   });
  });
</script>
<?php
}
add_action('wp_footer', 'intl_tel_input_javascript');
